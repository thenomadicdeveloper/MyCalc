//
//  Digit.swift
//  MyCalc
//
//  Created by Davin Henrik on 1/11/23.
//

import Foundation

enum Digit: Int, CaseIterable, CustomStringConvertible {
    case zero, one, two, three, four, five, six, seven, eight, nine
    
    var description: String {
        "\(rawValue)"
    }
}
