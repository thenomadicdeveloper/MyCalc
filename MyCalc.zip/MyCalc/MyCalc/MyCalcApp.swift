//
//  MyCalcApp.swift
//  MyCalc
//
//  Created by Davin Henrik on 1/11/23.
//

import SwiftUI

@main
struct MyCalcApp: App {
    var body: some Scene {
           WindowGroup {
               CalculatorView()
                   .environmentObject(CalculatorView.ViewModel())
           }
    }
}
