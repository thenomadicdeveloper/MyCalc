//
//  NumericalDisplays.swift
//  MyCalc
//
//  Created by Davin Henrik on 1/11/23.
//

import SwiftUI

struct NumericalDisplays: View {
    var numbers: [Int] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var body: some View {
        VStack {
            ForEach(numbers, id: \.self) { number in
                Button("\(number)") {}
            }
        }
    }
}

struct NumericalDisplays_Previews: PreviewProvider {
    static var previews: some View {
        NumericalDisplays()
    }
}
