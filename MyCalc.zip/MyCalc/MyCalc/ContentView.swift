//
//  ContentView.swift
//  MyCalc
//
//  Created by Davin Henrik on 1/11/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       CalculatorView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
