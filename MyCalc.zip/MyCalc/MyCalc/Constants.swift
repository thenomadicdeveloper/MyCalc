//
//  Constants.swift
//  MyCalc
//
//  Created by Davin Henrik on 1/11/23.
//

import Foundation
import CoreGraphics

struct Constants {
    static let padding: CGFloat = 12.0
}
